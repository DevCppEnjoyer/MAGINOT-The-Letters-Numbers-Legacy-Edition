
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

struct general{
int HP;
int Demage;
int Price;
int Number;
int MK;
};


struct doctrines{
int IDactivation;	
int HP_BUFF;
int DMG_BUFF;
int MKLEVEL;
int NERFPRICE;
};



int stuka_diving(){
system("cls");      
printf("STUKA DIVERS BOMBING OUR DEFENCES, YOU CANT DO ANYTHING TO STOP!!!\n");                                                                   
printf("                    +\n");                                                                       
printf("                    -##+                \n");                                                              
printf("                    .####+                \n");                                                           
printf("                     #####+                        \n");                                                   
printf("                     ######+-                                      -    \n");                              
printf("                     ######+#++                                  .###+#+.    \n");                         
printf("                  -#+######+++-++                               ##########-    \n");                       
printf("               .#+++-######+.#.---                            .###+####+###+    \n");                      
printf("             ####++++######--.---.                           ######+###+####     \n");                     
printf("              ##############----.                          .###+###########+      \n");                    
printf("               #############----                          ############+####.      \n");                    
printf("                ############+-+                         +##########++#####+       \n");                    
printf("             .-  ##########++-.                        ###+##+############-        \n");                   
printf("             ###-   #######+-++                       #######++##+++++###+.       \n");                    
printf("                      ########++                     #########++##++##+#++        \n");                    
printf("                      +##########+                 .###############++#+++-       \n");                     
printf("                      -############-              .###+###+#########++#++         \n");                    
printf("                       ############ .            .###-#+##-#########+#++-         \n");                    
printf("    ##.                 ########## ### .-       .###+###+-+###########++.          \n");                   
printf("    +######               +#- ######..#+.++    .##############-+###-+#+-           \n");                   
printf("    #########                   ######### +##-.###############-#####+##-            \n");                  
printf(" +######+.--#+                   -######################+#####-+######+-            \n");                  
printf("######### .-+                      ####################++#######-#####+            \n");                   
printf(".###########.                 #      #######################-+#######+-            \n");                   
printf(" -#########-                ######    .#####################+#++#####+-             \n");                  
printf("#--+#######.               ########    +#############################+              \n");                  
printf("     #######             +#########.      ###########################+              \n");                  
printf("      .######-          ###########         ########################+-               \n");                 
printf("       -######         ############        ##.######################+..               \n");                
printf("         .###### .    ############+        ###+#####################+ -               \n");                
printf("           ######+.+ #############+        -##-#####################+ .                 \n");              
printf("             #####################.         ## #####################-+#++.                \n");            
printf("              ####################.         ##.##+##################-#+-+#+                \n");           
printf("                ##################          .#-###############+#+++#+####+++.               \n");          
printf("                --################           +#-##########+++#+.#############+                 \n");       
printf("                   ###############-           .+.##########+- ###############+++               \n");       
printf("                  ###############  -          ---########++-##################++.                  \n");  
printf("                   +################. -         --###+####+-.-####################+                 \n");  
printf("                    #.################.          +-#######+. .#####################+-               \n");  
printf("                    ###################+          -+#######++##################+####++              \n");  
printf("                      ########++#########          - #+##################  ######+####++            \n");  
printf("                       ####+--############-     .   - #############- -##-    +#########++           \n");  
printf("                       ###+--###############     ### #.###########+   -##+++.   +#####++-+          \n");  
printf("                       ####+ ################-    ################.+  ######+-    .####++##         \n");  
printf("                        #######################    ###############.     .####+- ##+#+####-.         \n");  
printf("                      +#-  #######+ #---########    #############+.        ###+##########           \n");  
printf("                       -###########.###+ -#####++. ###############-          ++#.     .#- .#-       \n");  
printf("                        -##########.  ##########   ###############.                                 \n");  
printf("                        ###### ####+    ##   -#.-+  ######## #####-                                 \n");  
printf("                        -#####   ###-        --             - ++++-                                 \n");  
printf("                                   -#       .                 .-+#+                                 \n");  
printf("                                     +                          ++#                                 \n");  
printf("                                                                  +      	                           	\n");  
system("pause");
system("cls");
};

int main(void)
{
int sempre = 1,sempre2 = 1;

do{
printf(".....................................................................\n");
printf(".....................................................................\n");
printf("............0000000.............000000...0000........................\n");
printf("..........00000000000.........0000000000000000000000.................\n");
printf(".........000#000000000......000000000######000000000000..............\n");
printf(".........#####0000####......##################0000#####..............\n");
printf("......###################..##############################............\n");
printf("....######################.###################################.......\n");
printf("...##############################################################....\n");
printf("...##############################################################....\n");
printf("---------------------------------------------------------------------\n");
printf("##::::'##::::'###:::::'######:::'####:'##::: ##::'#######::'########:\n");
printf("###::'###:::'## ##:::'##... ##::. ##:: ###:: ##:'##.... ##:... ##..::\n");
printf("####'####::'##:. ##:: ##:::..:::: ##:: ####: ##: ##:::: ##:::: ##::::\n");
printf("## ### ##:'##:::. ##: ##::'####:: ##:: ## ## ##: ##:::: ##:::: ##::::\n");
printf("##. #: ##: #########: ##::: ##::: ##:: ##. ####: ##:::: ##:::: ##::::\n");
printf("##:.:: ##: ##.... ##: ##::: ##::: ##:: ##:. ###: ##:::: ##:::: ##::::\n");
printf("##:::: ##: ##:::: ##:. ######:::'####: ##::. ##:. #######::::: ##::::\n");
printf("..:::::..::..:::::..:::......::::....::..::::..:::.......::::::..::::\n");
printf("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\n");
printf(":::::::::::::::::Lether & Numbers Legacy Edition:::::::::::::::::::::\n");
printf("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\n");
printf(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n");
printf(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n");
printf(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n");
printf("PS:Please play in fullscreen!");
printf("\n1:FreePlay");
printf("\n2:Wiki");
printf("\n3:Exit");

int menu,i,k,budget=1000,researchpoints=0,warnings;
//budget=9999;
scanf("%d",&menu);
switch(menu)
{
case 1:
{
system("cls");
printf("Warnings: 1:YES/0:NO");
scanf("%d",&warnings);
system("cls");
//int IDactivation;	
//int HP_BUFF;
//int DMG_BUFF;
//int MKLEVEL;
//int NERFPRICE;
int activetedID = 0;
int MKlevel = 1,MKenemy = 0;
struct doctrines INDUSTRY_IMPROVEMENT = {1,10,10,1,2};
struct doctrines NERF_PRICES = {2,0,0,2,MKlevel};
struct doctrines PROFESSIONAL_ARMY = {3,15,15,3,0};
struct doctrines LORRAINE_WALLS = {4,40,5,4,0};
struct doctrines FRENCH_FURY = {5,0,0,5,0};
struct general PzII = {5,5,0,3,1};
struct general PzIII = {10,5,0,0,2};
struct general PzIV = {15,10,0,0,3};
struct general PzIV_H = {15,15,0,0,4};
struct general BroomBar = {15,30,0,0,5};
struct general BMK1 = {15,5,250,2,1};
struct general BMK2 = {20,10,500,0,2};
struct general BMK3 = {25,15,750,0,3};
struct general BMK4 = {30,20,1000,0,4};
struct general BMK5 = {35,25,1250,0,5};
struct general CMK1 = {5,15,250,2,1};
struct general CMK2 = {10,20,500,0,2};
struct general CMK3 = {15,25,750,0,3};
struct general CMK4 = {20,30,1000,0,4};
struct general CMK5 = {25,35,1250,0,5};
int D1=0;
int D2=0;
int D3=0;
int D4=0;
int D5=0;
do{
	int STUKADIVING;
	srand(time(NULL));
	if(MKenemy==1||MKlevel==1)
	STUKADIVING=rand()%50;
	if(MKenemy==2||MKlevel==2)
	STUKADIVING=rand()%40;
	if(MKenemy==3||MKlevel==3)
	STUKADIVING=rand()%35;
	if(MKenemy==4||MKlevel==4)
	STUKADIVING=rand()%35;
	if(MKenemy==5||MKlevel==5)
	STUKADIVING=rand()%40;
	if(STUKADIVING==1)
	{
	stuka_diving();   
BMK1.Number=BMK1.Number/2;
BMK2.Number=BMK2.Number/2;
BMK3.Number=BMK3.Number/2;
BMK4.Number=BMK4.Number/2;
BMK5.Number=BMK5.Number/2;
CMK1.Number=CMK1.Number/2;
CMK2.Number=CMK2.Number/2;
CMK3.Number=CMK3.Number/2;
CMK4.Number=CMK4.Number/2;
CMK5.Number=CMK5.Number/2;        
	}
	
	int B1=BMK1.Number;
		int B2=BMK2.Number;
		int B3=BMK3.Number;
		int B4=BMK4.Number;
		int B5=BMK5.Number;
		int C1=CMK1.Number;
		int C2=CMK2.Number;
		int C3=CMK3.Number;
		int C4=CMK4.Number;
		int C5=CMK5.Number;
		D1=0;
		D2=0;
		D3=0;
		D4=0;
		D5=0;
BMK1 = {15,5,250,B1,1};
BMK2 = {20,10,500,B2,2};
BMK3 = {25,15,750,B3,3};
BMK4 = {30,20,1000,B4,4};
BMK5 = {35,25,1250,B5,5};
CMK1 = {5,15,250,C1,1};
CMK2 = {10,20,500,C2,2};
CMK3 = {15,25,750,C3,3};
CMK4 = {20,30,1000,C4,4};
CMK5 = {25,35,1250,C5,5};

	switch(activetedID)
	{   
	
		case 0:
		{
		D1=0;
		D2=0;
		D3=0;
		D4=0;
		D5=0;
		break;
		}
		case 1:
		{
		if(D1==0)
		{
		D1=1;
		D2=0;
		D3=0;
		D4=0;
		D5=0;
		BMK1.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		BMK2.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		BMK3.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		BMK4.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		BMK5.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		CMK1.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		CMK2.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		CMK3.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		CMK4.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		CMK5.Demage+=INDUSTRY_IMPROVEMENT.DMG_BUFF;
		BMK1.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		BMK2.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		BMK3.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		BMK4.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		BMK5.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		CMK1.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		CMK2.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		CMK3.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		CMK4.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		CMK5.HP+=INDUSTRY_IMPROVEMENT.HP_BUFF;
		BMK1.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		BMK2.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		BMK3.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		BMK4.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		BMK5.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		CMK1.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		CMK2.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		CMK3.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		CMK4.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
		CMK5.Price/=INDUSTRY_IMPROVEMENT.NERFPRICE;
	 	}
		break;
		}
		
		case 2:
		{
		if(D2==0)
		{
		D1=0;
		D2=1;
		D3=0;
		D4=0;
		D5=0;
		doctrines NERF_PRICES = {2,0,0,2,MKlevel};
		BMK1.Price/=NERF_PRICES.NERFPRICE;
		BMK2.Price/=NERF_PRICES.NERFPRICE;
		BMK3.Price/=NERF_PRICES.NERFPRICE;
		BMK4.Price/=NERF_PRICES.NERFPRICE;
		BMK5.Price/=NERF_PRICES.NERFPRICE;
		CMK1.Price/=NERF_PRICES.NERFPRICE;
		CMK2.Price/=NERF_PRICES.NERFPRICE;
		CMK3.Price/=NERF_PRICES.NERFPRICE;
		CMK4.Price/=NERF_PRICES.NERFPRICE;
		CMK5.Price/=NERF_PRICES.NERFPRICE;
		}
		break;
		}
		case 3:
		{
		if(D3==0)
		{
		D1=0;
		D2=0;
		D3=1;
		D4=0;
		D5=0;
		BMK1.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		BMK2.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		BMK3.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		BMK4.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		BMK5.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		CMK1.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		CMK2.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		CMK3.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		CMK4.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		CMK5.Demage+=PROFESSIONAL_ARMY.DMG_BUFF;
		BMK1.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		BMK2.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		BMK3.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		BMK4.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		BMK5.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		CMK1.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		CMK2.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		CMK3.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		CMK4.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		CMK5.HP+=PROFESSIONAL_ARMY.HP_BUFF;
		}
		break;
		}
		case 4:
		{
		if(D4==0)
		{
		D1=0;
		D2=0;
		D3=0;
		D4=1;
		D5=0;
		BMK1.Demage+=LORRAINE_WALLS.DMG_BUFF;
		BMK2.Demage+=LORRAINE_WALLS.DMG_BUFF;
		BMK3.Demage+=LORRAINE_WALLS.DMG_BUFF;
		BMK4.Demage+=LORRAINE_WALLS.DMG_BUFF;
		BMK5.Demage+=LORRAINE_WALLS.DMG_BUFF;
		CMK1.Demage+=LORRAINE_WALLS.DMG_BUFF;
		CMK2.Demage+=LORRAINE_WALLS.DMG_BUFF;
		CMK3.Demage+=LORRAINE_WALLS.DMG_BUFF;
		CMK4.Demage+=LORRAINE_WALLS.DMG_BUFF;
		CMK5.Demage+=LORRAINE_WALLS.DMG_BUFF;
		BMK1.HP+=LORRAINE_WALLS.HP_BUFF;
		BMK2.HP+=LORRAINE_WALLS.HP_BUFF;
		BMK3.HP+=LORRAINE_WALLS.HP_BUFF;
		BMK4.HP+=LORRAINE_WALLS.HP_BUFF;
		BMK5.HP+=LORRAINE_WALLS.HP_BUFF;
		CMK1.HP+=LORRAINE_WALLS.HP_BUFF;
		CMK2.HP+=LORRAINE_WALLS.HP_BUFF;
		CMK3.HP+=LORRAINE_WALLS.HP_BUFF;
		CMK4.HP+=LORRAINE_WALLS.HP_BUFF;
		CMK5.HP+=LORRAINE_WALLS.HP_BUFF;
		}
		break;
		}
		case 5:
			{
		D1=0;
		D2=0;
		D3=0;
		D4=0;
		D5=1;
		if(STUKADIVING==1)
	{  
PzII.Number=0;
PzIII.Number=0;       
PzIV.Number=0;  
PzIV_H.Number=0;  
BroomBar.Number=0;
	}
	break;
	}
}
	int PzII_Rand=rand()%6;
	int PzIII_Rand=rand()%6;
	int PzIV_Rand=rand()%6;
	int PzIV_H_Rand=rand()%6;
	int BroomBar_Rand=rand()%6;
	srand(time(NULL));
int FRENCH_DMG=(BMK1.Demage*BMK1.Number);
	FRENCH_DMG+=(BMK2.Demage*BMK2.Number);
	FRENCH_DMG+=(BMK3.Demage*BMK3.Number);
	FRENCH_DMG+=(BMK4.Demage*BMK4.Number);
	FRENCH_DMG+=(BMK5.Demage*BMK5.Number);
	FRENCH_DMG+=(CMK1.Demage*CMK1.Number);
	FRENCH_DMG+=(CMK2.Demage*CMK2.Number);
	FRENCH_DMG+=(CMK3.Demage*CMK3.Number);
	FRENCH_DMG+=(CMK4.Demage*CMK4.Number);
	FRENCH_DMG+=(CMK5.Demage*CMK5.Number);
int GERMAN_DMG=(PzII.Demage*PzII.Number);
	GERMAN_DMG+=(PzIII.Demage*PzIII.Number);
	GERMAN_DMG+=(PzIV.Demage*PzIV.Number);
	GERMAN_DMG+=(PzIV_H.Demage*PzIV_H.Number);
	GERMAN_DMG+=(BroomBar.Demage*BroomBar.Number);
int BMK1_ALL_HP=(BMK1.Number*BMK1.HP);
int BMK2_ALL_HP=(BMK2.Number*BMK2.HP);
int BMK3_ALL_HP=(BMK3.Number*BMK3.HP);
int BMK4_ALL_HP=(BMK4.Number*BMK4.HP);
int BMK5_ALL_HP=(BMK5.Number*BMK5.HP);
int CMK1_ALL_HP=(CMK1.Number*CMK1.HP);
int CMK2_ALL_HP=(CMK2.Number*CMK2.HP);
int CMK3_ALL_HP=(CMK3.Number*CMK3.HP);
int CMK4_ALL_HP=(CMK4.Number*CMK4.HP);
int CMK5_ALL_HP=(CMK5.Number*CMK5.HP);
int FRENCH_NUMBER=(BMK1.Number+BMK2.Number+BMK3.Number+BMK4.Number+BMK5.Number+CMK1.Number+CMK2.Number+CMK3.Number+CMK4.Number+CMK5.Number);
int _1 = PzII.Number;
int _2 = PzIII.Number;
int _3 = PzIV.Number;
int _4 = PzIV_H.Number;
int _5 = BroomBar.Number;
if(BMK1.Number<=0&&BMK2.Number<=0&&BMK3.Number<=0&&BMK4.Number<=0&&BMK5.Number<=0&&CMK1.Number<=0&&CMK2.Number<=0&&CMK3.Number<=0&&CMK4.Number<=0&&CMK5.Number<=0||budget<0)
{
system("cls");
printf("::::::::::::::::::::::::::::::::::\n");
printf("::::::::::::::::::::::::::::::::::\n");
printf(":::::::::::::::DEFEAT:::::::::::::\n");
printf("::::::::::::::::::::::::::::::::::\n");
printf("::::::::::::::::::::::::::::::::::\n");
printf("::::::::::::::::::::::::::::::::::\n");
printf("::::::::::::::::::::::::::::::::::\n");
printf("::::::::0000::::::::00000:::::::::\n");
printf(":::000::0000########00000:::::::::\n");
printf(":::0####0000##########00#####:::::\n");
printf("##################################\n");
if(budget<0)
{
printf("YOU LOST ALL BUDGET\n");
}
if(FRENCH_NUMBER<0)
{
printf("YOU LOST ALL DEFENCES\n");
}
printf("Score:%d\n",MKenemy);
break;
}
else

if(PzII.Number==0&&(MKlevel>=1||MKenemy>0))
PzII.Number=PzII_Rand;	
if(PzIII.Number==0&&(MKlevel>=2||MKenemy>=10))
PzIII.Number=PzIII_Rand;
if(PzIV.Number==0&&(MKlevel>=3||MKenemy>=20))
PzIV.Number=PzIV_Rand;
if(PzIV_H.Number==0&&(MKlevel>=4||MKenemy>=30))
PzIV_H.Number=PzIV_H_Rand;
if(BroomBar.Number==0&&(MKlevel==5||MKenemy>=40))
BroomBar.Number=BroomBar_Rand;



system("cls");
if(BMK1.Number>8)
BMK1.Number=8;
if(BMK2.Number>8)
BMK2.Number=8;
if(BMK3.Number>8)
BMK3.Number=8;
if(BMK4.Number>8)
BMK4.Number=8;
if(BMK5.Number>8)
BMK5.Number=8;
if(CMK1.Number>8)
CMK1.Number=8;
if(CMK2.Number>8)
CMK2.Number=8;
if(CMK3.Number>8)
CMK3.Number=8;
if(CMK4.Number>8)
CMK4.Number=8;
if(CMK5.Number>8)
CMK5.Number=8;
if(CMK1.Number>0)
{
for(i=0;i<CMK1.Number;i++)
{printf(":###::::::: ");}
printf("\n");
for(i=0;i<CMK1.Number;i++)
{printf(":::###::::: ");}
printf("\n");
for(i=0;i<CMK1.Number;i++)
{printf(":::::#1##:: ");}
printf("\n");
for(i=0;i<CMK1.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(CMK2.Number>0)
{
for(i=0;i<CMK2.Number;i++)
{printf(":###::::::: ");}
printf("\n");
for(i=0;i<CMK2.Number;i++)
{printf(":::###::::: ");}
printf("\n");
for(i=0;i<CMK2.Number;i++)
{printf(":::::#2##:: ");}
printf("\n");
for(i=0;i<CMK2.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(CMK3.Number>0)
{
for(i=0;i<CMK3.Number;i++)
{printf(":###::::::: ");}
printf("\n");
for(i=0;i<CMK3.Number;i++)
{printf(":::###::::: ");}
printf("\n");
for(i=0;i<CMK3.Number;i++)
{printf(":::::#3##:: ");}
printf("\n");
for(i=0;i<CMK3.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(CMK4.Number>0)
{
for(i=0;i<CMK4.Number;i++)
{printf(":###::::::: ");}
printf("\n");
for(i=0;i<CMK4.Number;i++)
{printf(":::###::::: ");}
printf("\n");
for(i=0;i<CMK4.Number;i++)
{printf(":::::#4##:: ");}
printf("\n");
for(i=0;i<CMK4.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(CMK5.Number>0)
{
for(i=0;i<CMK5.Number;i++)
{printf(":###::::::: ");}
printf("\n");
for(i=0;i<CMK5.Number;i++)
{printf(":::###::::: ");}
printf("\n");
for(i=0;i<CMK5.Number;i++)
{printf(":::::#5##:: ");}
printf("\n");
for(i=0;i<CMK5.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(BMK5.Number>0)
{
for(i=0;i<BMK5.Number;i++)
{printf(":::#####::: ");}
printf("\n");
for(i=0;i<BMK5.Number;i++)
{printf("########### ");}
printf("\n");
for(i=0;i<BMK5.Number;i++)
{printf("::###5###:: ");}
printf("\n");
for(i=0;i<BMK5.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(BMK4.Number>0)
{
for(i=0;i<BMK4.Number;i++)
{printf(":::#####::: ");}
printf("\n");
for(i=0;i<BMK4.Number;i++)
{printf("########### ");}
printf("\n");
for(i=0;i<BMK4.Number;i++)
{printf("::###4###:: ");}
printf("\n");
for(i=0;i<BMK4.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(BMK3.Number>0)
{
for(i=0;i<BMK3.Number;i++)
{printf(":::#####::: ");}
printf("\n");
for(i=0;i<BMK3.Number;i++)
{printf("########### ");}
printf("\n");
for(i=0;i<BMK3.Number;i++)
{printf("::###3###:: ");}
printf("\n");
for(i=0;i<BMK3.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(BMK2.Number>0)
{
for(i=0;i<BMK2.Number;i++)
{printf(":::#####::: ");}
printf("\n");
for(i=0;i<BMK2.Number;i++)
{printf("########### ");}
printf("\n");
for(i=0;i<BMK2.Number;i++)
{printf("::###2###:: ");}
printf("\n");
for(i=0;i<BMK2.Number;i++)
{printf("########### ");}
printf("\n\n");
}
if(BMK1.Number>0)
{
for(i=0;i<BMK1.Number;i++)
{printf(":::#####::: ");}
printf("\n");
for(i=0;i<BMK1.Number;i++)
{printf("########### ");}
printf("\n");
for(i=0;i<BMK1.Number;i++)
{printf("::###1###:: ");}
printf("\n");
for(i=0;i<BMK1.Number;i++)
{printf("########### ");}
printf("\n\n");
}
printf("\n");
for(i=0;i<120;i++)
{printf("#");}
printf("\n\n");
if(PzII.Number>0)
{
for(i=0;i<PzII.Number;i++)
{printf("____&&~_ ");}
printf("\n");
for(i=0;i<PzII.Number;i++)
{printf("--00000- ");}
printf("\n\n");
}
if(PzIII.Number>0)
{
for(i=0;i<PzIII.Number;i++)
{printf("___&&&-_ ");}
printf("\n");
for(i=0;i<PzIII.Number;i++)
{printf("-000000- ");}
printf("\n\n");
}
if(PzIV.Number>0)
{
for(i=0;i<PzIV.Number;i++)
{printf("__0###-__ ");}
printf("\n");
for(i=0;i<PzIV.Number;i++)
{printf("-000000-  ");}
printf("\n\n");
}
if(PzIV_H.Number>0)
{
for(i=0;i<PzIV_H.Number;i++)
{printf("__0###-__ ");}
printf("\n");
for(i=0;i<PzIV_H.Number;i++)
{printf("-0#####0- ");}
printf("\n\n");
}
if(BroomBar.Number>0)
{
for(i=0;i<BroomBar.Number;i++)
{printf("/####co   ");}
printf("\n");
for(i=0;i<BroomBar.Number;i++)
{printf("-000000-  ");}
printf("\n\n");
}
for(i=0;i<120;i++)
{printf(":");}
printf("\n\n");
printf("    #        #         1      ****::#::****  #|||##|||||##+   |1-2-3-4-5    #     #   | ####     #### \n");
printf(" #######    ###        1      ****#####****  #|||##|||||###+  |:::::::::  ##### ##### | ###### ###### \n");
printf(" #  #      #####       1      ***:**#**:***  #M:A:G:I:N:O:T#  |::#####::  # #   # #   | ### ##### ### \n");
printf(" #######  #12345#      1      *###########*  ###############  |:#######:  ##### ##### | ###  ###  ### \n");
printf("    #  # ### # ### ####0##### ***:::#:::***  ####Lethers####  |::#####::    # #   # # | ###  THX  ### \n");
printf(" #######     #         3      ***:::#:::***  ###& Numbers###  |:#######:  ##### ##### | ###  For  ### \n");
printf("    #       ###        3      ***:::#:::***  ###############  |:MAGINOT:    #     #   | ###Playing### \n");
printf("\n 1:Buy   2:Upgrade MK 3:Attack 4:Doctrines  5:(IN DEVELOPMENT)| Level:%d Budget:%d$   	M:A:G:I:N:O:T\n",MKlevel,budget,researchpoints);
for(i=0;i<120;i++)

{printf("-");}
printf("\n\n");
printf("Attention:The Max of building per fortification is 8\nAttention: In the (buy) section, if you select a number without anything, you will not buy anything\nAttention:Everytime new enemies are coming\n"); 
if(activetedID==1)
{
printf("#:#o oo         #:#\n");
printf("#:#OO OO        #:#\n");
printf("#:# OO OO       #:#\n");
printf("#:#  || ||      #:#\n");
printf("#:#  |# #|# #   #:#\n");
printf("#:# ##########  #:#\n");
printf("#:# ##########  #:#\n");
printf("#:# ##########  #:#\n");
}
if(activetedID==2)
{	
printf("#:#-------------#:#\n");
printf("#:#   #     #   #:#\n");
printf("#:# ##### ##### #:#\n");
printf("#:# # #   # #   #:#\n");
printf("#:# ##### ##### #:#\n");
printf("#:#   # #   # # #:#\n");
printf("#:# ##### ##### #:#\n");
printf("#:#   #     #   #:#\n");
printf("#:#-------------#:#\n");
}
if(activetedID==3)
{	
printf("#::::::#:|:::###::#\n");
printf("#:::::#::|::#####:#\n");
printf("#::###:::|:::###::#\n");
printf("#:#####::|::#####:#\n");
printf("---------#---------\n");
printf("#::###:::|:#::::::#\n");
printf("#:#####::|::#:::::#\n");
printf("#::###:::|:::###::#\n");
printf("#:#####::|::#####:#\n");
}
if(activetedID==4)
{	
printf("#::#############::#\n");           
printf("#:##           ##:#\n");           
printf("#:## ###   ### ##:#\n");           
printf("#:## #### #### ##:#\n");           
printf("#:## ## ### ## ##:#\n");
printf("#:## ##  #  ## ##:#\n");           
printf("#::####     ####::#\n");      
printf("#::::###   ###::::#\n");       
printf("#:::::::###:::::::#\n");
}
if(activetedID==5)
{
printf("#:#:::::::::::::#:#\n");
printf("#:#::::::#::::::#:#\n");
printf("#:#:::#######:::#:#\n");
printf("#:#::::::#::::::#:#\n");
printf("#:#:###########:#:#\n");
printf("#:#::::::#::::::#:#\n");
printf("#:#::::::#::::::#:#\n");
printf("#:#::::::#::::::#:#\n");
printf("#:#::::::#::::::#:#\n");
}




if(warnings==1)
{
if(budget<=250||FRENCH_NUMBER<3)
{
printf("\n");
printf("           ##\n");
printf("          ####\n");
printf("         ######\n");
printf("        ###  ###\n");
printf("       ###    ###\n");
printf("      ###  ##  ###\n");
printf("     ###   ##   ###\n");
printf("    ###    ##    ###\n");
printf("   ###     ##     ###\n");
printf("  ###              ###\n");
printf(" ###       ##       ###\n");
printf(" ######################\n");
printf("  ####################\n ");
}
}
printf("\n\n");
int menu2;
scanf("%d",&menu2);
system("cls");
if(menu2==1)
{
if(MKlevel>=1)
{
printf("(1)Bunker MK1:	(2)Cannon MK1\n");
printf("Sprite:		Sprite:			\n");
printf("::#######::	:###:::::::		\n");
printf("###########	:::###:::::		\n");
printf("::###1###::	:::::#1##::		\n");
printf("###########	###########		\n");
printf("    %d$	    %d$		\n",CMK1.Price,BMK1.Price);
if(MKlevel==1)
{
int Buy;
scanf("%d",&Buy);
switch(Buy)
{
case 1:
{
BMK1.Number+=1;
budget-=BMK1.Price;
break;
}
case 2:
{
CMK1.Number+=1;
budget-=CMK1.Price;
break;
}
default:
{
system("cls");
}
}
}
}
if(MKlevel>=2)
{
printf("(3)Bunker MK2:	(4)Cannon MK2\n");
printf("Sprite:		Sprite:			\n");
printf("::#######::	:###:::::::		\n");
printf("###########	:::###:::::		\n");
printf("::###2###::	:::::#2##::		\n");
printf("###########	###########		\n");
printf("    %d$	    %d$		\n",CMK2.Price,BMK2.Price);
if(MKlevel==2)
{
int Buy;
scanf("%d",&Buy);
switch(Buy)
{
case 1:
{
BMK1.Number+=1;
budget-=BMK1.Price;
break;
}
case 2:
{
CMK1.Number+=1;
budget-=CMK1.Price;
break;
}
case 3:
{
BMK2.Number+=1;
budget-=BMK2.Price;
break;
}
case 4:
{
CMK2.Number+=1;
budget-= CMK2.Price;
break;
}
default:
{
system("cls");
}
}
}
}
if(MKlevel>=3)
{
printf("(5)Bunker MK3:	(6)Cannon MK3\n");
printf("Sprite:		Sprite:			\n");
printf("::#######::	:###:::::::		\n");
printf("###########	:::###:::::		\n");
printf("::###3###::	:::::#3##::		\n");
printf("###########	###########		\n");
printf("    %d$	    %d$		\n",CMK3.Price,BMK3.Price);
if(MKlevel==3)
{
int Buy;
scanf("%d",&Buy);
switch(Buy)
{
case 1:
{
BMK1.Number+=1;
budget-=BMK1.Price;
break;
}
case 2:
{
CMK1.Number+=1;
budget-=CMK1.Price;
break;
}
case 3:
{
BMK2.Number+=1;
budget-=BMK2.Price;
break;
}
case 4:
{
CMK2.Number+=1;
budget-= CMK2.Price;
break;
}
case 5:
{
BMK3.Number+=1;
budget-= BMK3.Price;
break;
}
case 6:
{
CMK3.Number+=1;
budget-= CMK3.Price;
break;
}
default:
{
system("cls");
}
}
}
}
if(MKlevel>=4)
{
printf("(7)Bunker MK4:	(8)Cannon MK4\n");
printf("Sprite:		Sprite:			\n");
printf("::#######::	:###:::::::		\n");
printf("###########	:::###:::::		\n");
printf("::###4###::	:::::#4##::		\n");
printf("###########	###########		\n");
printf("    %d$	    %d$		\n",CMK4.Price,BMK4.Price);
if(MKlevel==4)
{
int Buy;
scanf("%d",&Buy);
switch(Buy)
{
case 1:
{
BMK1.Number+=1;
budget-=BMK1.Price;
break;
}
case 2:
{
CMK1.Number+=1;
budget-=CMK1.Price;
break;
}
case 3:
{
BMK2.Number+=1;
budget-=BMK2.Price;
break;
}
case 4:
{
CMK2.Number+=1;
budget-= CMK2.Price;
break;
}
case 5:
{
BMK3.Number+=1;
budget-= BMK3.Price;
break;
}
case 6:
{
CMK3.Number+=1;
budget-= CMK3.Price;
break;
}
case 7:
{
BMK4.Number+=1;
budget-= BMK4.Price;
break;
}
case 8:
{
CMK4.Number+=1;
budget-= CMK4.Price;
break;
}
default:
{
system("cls");
}
}
}
}
if(MKlevel==5)
{
printf("(9)Bunker MK5:	(10)Cannon MK5\n");
printf("Sprite:		Sprite:			\n");
printf("::#######::	:###:::::::		\n");
printf("###########	:::###:::::		\n");
printf("::###5###::	:::::#5##::		\n");
printf("###########	###########		\n");
printf("    %d$	    %d$		\n",CMK5.Price,BMK5.Price);
if(MKlevel==5)
{
int Buy;
scanf("%d",&Buy);
switch(Buy)
{
case 1:
{
BMK1.Number+=1;
budget-=BMK1.Price;
break;
}
case 2:
{
CMK1.Number+=1;
budget-=CMK1.Price;
break;
}
case 3:
{
BMK2.Number+=1;
budget-=BMK2.Price;
break;
}
case 4:
{
CMK2.Number+=1;
budget-= CMK2.Price;
break;
}
case 5:
{
BMK3.Number+=1;
budget-= BMK3.Price;
break;
}
case 6:
{
CMK3.Number+=1;
budget-= CMK3.Price;
break;
}
case 7:
{
BMK4.Number+=1;
budget-= BMK4.Price;
break;
}
case 8:
{
CMK4.Number+=1;
budget-= CMK4.Price;
break;
}
case 9:
{
BMK5.Number+=1;
budget-= BMK5.Price;
break;
}
case 10:
{
CMK5.Number+=1;
budget-=CMK5.Price;
break;
}
default:
{
system("cls");
}
}
}
}
}
if(menu2==2)
{
if(MKlevel==1)
{
system("cls");
printf("Upgrade MK(%d$)\n1:yes\n2,3,4,5,6,7,8,9 and 0:No\n",BMK2.Price+CMK2.Price);
int OptionMK;
scanf("%d",&OptionMK);
if(budget>(BMK2.Price+CMK2.Price)&&OptionMK==1)
{
MKlevel+=1;
budget=budget-(BMK2.Price+CMK2.Price);
}
else
{
printf("YOU REFUSE OR LOW BUDGET");
system("pause");
}
}
if(MKlevel==2)
{
system("cls");
printf("Upgrade MK(%d$)\n1:yes\n2,3,4,5,6,7,8,9 and 0:No\n",BMK3.Price+CMK3.Price);
int OptionMK;
scanf("%d",&OptionMK);
if(budget>(BMK3.Price+CMK3.Price)&&OptionMK==1)
{
MKlevel+=1;
budget=budget-(BMK3.Price+CMK3.Price);
}
else
{
printf("YOU REFUSE OR LOW BUDGET");
system("pause");
}
}
if(MKlevel==3)
{
system("cls");
printf("Upgrade MK(%d$)\n1:yes\n2,3,4,5,6,7,8,9 and 0:No\n",BMK4.Price+CMK4.Price);
int OptionMK;
scanf("%d",&OptionMK);
if(budget>(BMK4.Price+CMK4.Price)&&OptionMK==1)
{
MKlevel+=1;
budget=budget-(BMK4.Price+CMK4.Price);
}
else
{
printf("YOU REFUSE OR LOW BUDGET");
system("pause");
}
}
if(MKlevel==4)
{
system("cls");
printf("Upgrade MK(%d$)\n1:yes\n2,3,4,5,6,7,8,9 and 0:No\n",BMK5.Price+CMK5.Price);
int OptionMK;
scanf("%d",&OptionMK);
if(budget>(BMK5.Price+CMK5.Price)&&OptionMK==1)
{
MKlevel+=1;
budget=budget-(BMK5.Price+CMK5.Price);
}
else
{
printf("YOU REFUSE OR LOW BUDGET");
system("pause");
}
}

if(MKlevel==5)
{
system("cls");
printf("YOU ARE IN MAX LEVEL!!!");
system("pause");
system("cls");
}
}
if(menu2==3)
{
printf("Chose your target\n");
printf("1:Panzer II	(%d)\n",PzII.Number);
printf("2:Panzer III	(%d)\n",PzIII.Number);
printf("3:Panzer IV	(%d)\n",PzIV.Number);
printf("4:Panzer IV-H	(%d)\n",PzIV_H.Number);
printf("5:BroomBar	(%d)\n",BroomBar.Number);
int attack_option;
scanf("%d",&attack_option);
switch(attack_option)
{
case 1:
{
 	BMK1_ALL_HP=BMK1_ALL_HP-GERMAN_DMG;
 	if(BMK1_ALL_HP<=0)
	BMK1.Number = 0;
	else
	BMK1.Number=BMK1_ALL_HP/BMK1.HP;
	
	BMK2_ALL_HP=BMK2_ALL_HP-GERMAN_DMG;
 	if(BMK2_ALL_HP<=0)
	BMK2.Number = 0;
	else
	BMK2.Number=BMK2_ALL_HP/BMK2.HP;
	
	BMK3_ALL_HP=BMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	BMK3.Number = 0;
	else
	BMK3.Number=BMK3_ALL_HP/BMK3.HP;
	
	BMK4_ALL_HP=BMK4_ALL_HP-GERMAN_DMG;
 	if(BMK4_ALL_HP<=0)
	BMK4.Number = 0;
	else
	BMK4.Number=BMK4_ALL_HP/BMK4.HP;
	
	BMK5_ALL_HP=BMK5_ALL_HP-GERMAN_DMG;
 	if(BMK5_ALL_HP<=0)
	BMK5.Number = 0;
	else
	BMK5.Number=BMK5_ALL_HP/BMK5.HP;
	
	CMK1_ALL_HP=CMK1_ALL_HP-GERMAN_DMG;
 	if(CMK1_ALL_HP<=0)
	CMK1.Number = 0;
	else
	CMK1.Number=CMK1_ALL_HP/CMK1.HP;
	
	CMK2_ALL_HP=CMK2_ALL_HP-GERMAN_DMG;
 	if(CMK2_ALL_HP<=0)
	CMK2.Number = 0;
	else
	CMK2.Number=CMK2_ALL_HP/CMK2.HP;
	
	CMK3_ALL_HP=CMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	CMK3.Number = 0;
	else
	CMK3.Number=CMK3_ALL_HP/CMK3.HP;
	
	CMK4_ALL_HP=CMK4_ALL_HP-GERMAN_DMG;
 	if(CMK4_ALL_HP<=0)
	CMK4.Number = 0;
	else
	CMK4.Number=CMK4_ALL_HP/CMK4.HP;
	
	CMK5_ALL_HP=CMK5_ALL_HP-GERMAN_DMG;
 	if(CMK5_ALL_HP<=0)
	CMK5.Number = 0;
	else
	CMK5.Number=CMK5_ALL_HP/CMK5.HP;
	
//	printf("FRENCH_DMG: %d",FRENCH_DMG);
int PzII_ALL_HP=(PzII.HP*PzII.Number);
//	printf("\nPzII ALL HP=%d",PzII_ALL_HP);
//system("pause");
	PzII_ALL_HP=PzII_ALL_HP-FRENCH_DMG;
	if(PzII_ALL_HP<0)
	PzII_ALL_HP = 0;
	PzII.Number=PzII_ALL_HP/PzII.HP;
//	printf("\nPzII ALL HP=%d",PzII_ALL_HP);
int Reward = 250 * _1-PzII_ALL_HP;
	budget += Reward;
	MKenemy+=1;
//	system("pause");
break;
}
case 2:
{
	BMK1_ALL_HP=BMK1_ALL_HP-GERMAN_DMG;
 	if(BMK1_ALL_HP<=0)
	BMK1.Number = 0;
	else
	BMK1.Number=BMK1_ALL_HP/BMK1.HP;
	
	BMK2_ALL_HP=BMK2_ALL_HP-GERMAN_DMG;
 	if(BMK2_ALL_HP<=0)
	BMK2.Number = 0;
	else
	BMK2.Number=BMK2_ALL_HP/BMK2.HP;
	
	BMK3_ALL_HP=BMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	BMK3.Number = 0;
	else
	BMK3.Number=BMK3_ALL_HP/BMK3.HP;
	
	BMK4_ALL_HP=BMK4_ALL_HP-GERMAN_DMG;
 	if(BMK4_ALL_HP<=0)
	BMK4.Number = 0;
	else
	BMK4.Number=BMK4_ALL_HP/BMK4.HP;
	
	BMK5_ALL_HP=BMK5_ALL_HP-GERMAN_DMG;
 	if(BMK5_ALL_HP<=0)
	BMK5.Number = 0;
	else
	BMK5.Number=BMK5_ALL_HP/BMK5.HP;
	
	CMK1_ALL_HP=CMK1_ALL_HP-GERMAN_DMG;
 	if(CMK1_ALL_HP<=0)
	CMK1.Number = 0;
	else
	CMK1.Number=CMK1_ALL_HP/CMK1.HP;
	
	CMK2_ALL_HP=CMK2_ALL_HP-GERMAN_DMG;
 	if(CMK2_ALL_HP<=0)
	CMK2.Number = 0;
	else
	CMK2.Number=CMK2_ALL_HP/CMK2.HP;
	
	CMK3_ALL_HP=CMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	CMK3.Number = 0;
	else
	CMK3.Number=CMK3_ALL_HP/CMK3.HP;
	
	CMK4_ALL_HP=CMK4_ALL_HP-GERMAN_DMG;
 	if(CMK4_ALL_HP<=0)
	CMK4.Number = 0;
	else
	CMK4.Number=CMK4_ALL_HP/CMK4.HP;
	
	CMK5_ALL_HP=CMK5_ALL_HP-GERMAN_DMG;
 	if(CMK5_ALL_HP<=0)
	CMK5.Number = 0;
	else
	CMK5.Number=CMK5_ALL_HP/CMK5.HP;
	
//	printf("FRENCH_DMG: %d",FRENCH_DMG);
int PzIII_ALL_HP=(PzIII.HP*PzIII.Number);
//	printf("\nPzIII ALL HP=%d",PzIII_ALL_HP);
//system("pause");
	PzIII_ALL_HP=PzIII_ALL_HP-FRENCH_DMG;
	if(PzIII_ALL_HP<0)
	PzIII_ALL_HP = 0;
	
	PzIII.Number=PzIII_ALL_HP/PzIII.HP;
//	printf("\nPzIII ALL HP=%d",PzIII_ALL_HP);
int Reward = 500 * _2 - PzIII_ALL_HP;
	budget += Reward;
	MKenemy+=1;
//	system("pause");
break;
}
case 3:
{
	BMK1_ALL_HP=BMK1_ALL_HP-GERMAN_DMG;
 	if(BMK1_ALL_HP<=0)
	BMK1.Number = 0;
	else
	BMK1.Number=BMK1_ALL_HP/BMK1.HP;
	
	BMK2_ALL_HP=BMK2_ALL_HP-GERMAN_DMG;
 	if(BMK2_ALL_HP<=0)
	BMK2.Number = 0;
	else
	BMK2.Number=BMK2_ALL_HP/BMK2.HP;
	
	BMK3_ALL_HP=BMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	BMK3.Number = 0;
	else
	BMK3.Number=BMK3_ALL_HP/BMK3.HP;
	
	BMK4_ALL_HP=BMK4_ALL_HP-GERMAN_DMG;
 	if(BMK4_ALL_HP<=0)
	BMK4.Number = 0;
	else
	BMK4.Number=BMK4_ALL_HP/BMK4.HP;
	
	BMK5_ALL_HP=BMK5_ALL_HP-GERMAN_DMG;
 	if(BMK5_ALL_HP<=0)
	BMK5.Number = 0;
	else
	BMK5.Number=BMK5_ALL_HP/BMK5.HP;
	
	CMK1_ALL_HP=CMK1_ALL_HP-GERMAN_DMG;
 	if(CMK1_ALL_HP<=0)
	CMK1.Number = 0;
	else
	CMK1.Number=CMK1_ALL_HP/CMK1.HP;
	
	CMK2_ALL_HP=CMK2_ALL_HP-GERMAN_DMG;
 	if(CMK2_ALL_HP<=0)
	CMK2.Number = 0;
	else
	CMK2.Number=CMK2_ALL_HP/CMK2.HP;
	
	CMK3_ALL_HP=CMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	CMK3.Number = 0;
	else
	CMK3.Number=CMK3_ALL_HP/CMK3.HP;
	
	CMK4_ALL_HP=CMK4_ALL_HP-GERMAN_DMG;
 	if(CMK4_ALL_HP<=0)
	CMK4.Number = 0;
	else
	CMK4.Number=CMK4_ALL_HP/CMK4.HP;
	
	CMK5_ALL_HP=CMK5_ALL_HP-GERMAN_DMG;
 	if(CMK5_ALL_HP<=0)
	CMK5.Number = 0;
	else
	CMK5.Number=CMK5_ALL_HP/CMK5.HP;
	
//	printf("FRENCH_DMG: %d",FRENCH_DMG);
int PzIV_ALL_HP=(PzIV.HP*PzIV.Number);
//	printf("\nPzIV ALL HP=%d",PzIV_ALL_HP);
//system("pause");
	PzIV_ALL_HP=PzIV_ALL_HP-FRENCH_DMG;
	if(PzIV_ALL_HP<0)
	PzIV_ALL_HP=0;
	PzIV.Number=PzIV_ALL_HP/PzIV.HP;
//	printf("\nPzIV ALL HP=%d",PzIV_ALL_HP);
int Reward = 750 * _3-PzIV_ALL_HP;
	budget += Reward;
	MKenemy+=1;
//	system("pause");
break;
}
case 4:
{
	BMK1_ALL_HP=BMK1_ALL_HP-GERMAN_DMG;
 	if(BMK1_ALL_HP<=0)
	BMK1.Number = 0;
	else
	BMK1.Number=BMK1_ALL_HP/BMK1.HP;
	
	BMK2_ALL_HP=BMK2_ALL_HP-GERMAN_DMG;
 	if(BMK2_ALL_HP<=0)
	BMK2.Number = 0;
	else
	BMK2.Number=BMK2_ALL_HP/BMK2.HP;
	
	BMK3_ALL_HP=BMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	BMK3.Number = 0;
	else
	BMK3.Number=BMK3_ALL_HP/BMK3.HP;
	
	BMK4_ALL_HP=BMK4_ALL_HP-GERMAN_DMG;
 	if(BMK4_ALL_HP<=0)
	BMK4.Number = 0;
	else
	BMK4.Number=BMK4_ALL_HP/BMK4.HP;
	
	BMK5_ALL_HP=BMK5_ALL_HP-GERMAN_DMG;
 	if(BMK5_ALL_HP<=0)
	BMK5.Number = 0;
	else
	BMK5.Number=BMK5_ALL_HP/BMK5.HP;
	
	CMK1_ALL_HP=CMK1_ALL_HP-GERMAN_DMG;
 	if(CMK1_ALL_HP<=0)
	CMK1.Number = 0;
	else
	CMK1.Number=CMK1_ALL_HP/CMK1.HP;
	
	CMK2_ALL_HP=CMK2_ALL_HP-GERMAN_DMG;
 	if(CMK2_ALL_HP<=0)
	CMK2.Number = 0;
	else
	CMK2.Number=CMK2_ALL_HP/CMK2.HP;
	
	CMK3_ALL_HP=CMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	CMK3.Number = 0;
	else
	CMK3.Number=CMK3_ALL_HP/CMK3.HP;
	
	CMK4_ALL_HP=CMK4_ALL_HP-GERMAN_DMG;
 	if(CMK4_ALL_HP<=0)
	CMK4.Number = 0;
	else
	CMK4.Number=CMK4_ALL_HP/CMK4.HP;
	
	CMK5_ALL_HP=CMK5_ALL_HP-GERMAN_DMG;
 	if(CMK5_ALL_HP<=0)
	CMK5.Number = 0;
	else
	CMK5.Number=CMK5_ALL_HP/CMK5.HP;
	
//	printf("FRENCH_DMG: %d",FRENCH_DMG);
int PzIV_H_ALL_HP=(PzIV_H.HP*PzIV_H.Number);
//	printf("\nPzIV H ALL HP=%d",PzII_H_ALL_HP);
//system("pause");
	PzIV_H_ALL_HP=PzIV_H_ALL_HP-FRENCH_DMG;
	if(PzIV_H_ALL_HP<0)
	PzIV_H_ALL_HP=0;
	PzIV_H.Number=PzIV_H_ALL_HP/PzIV_H.HP;
//	printf("\nPzIV H ALL HP=%d",PzIV_H_ALL_HP);
int Reward = 1000 * _4 - PzIV_H_ALL_HP;
	budget += Reward;
	MKenemy+=1;
//	system("pause");
break;
}
case 5:
{
	BMK1_ALL_HP=BMK1_ALL_HP-GERMAN_DMG;
 	if(BMK1_ALL_HP<=0)
	BMK1.Number = 0;
	else
	BMK1.Number=BMK1_ALL_HP/BMK1.HP;
	
	BMK2_ALL_HP=BMK2_ALL_HP-GERMAN_DMG;
 	if(BMK2_ALL_HP<=0)
	BMK2.Number = 0;
	else
	BMK2.Number=BMK2_ALL_HP/BMK2.HP;
	
	BMK3_ALL_HP=BMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	BMK3.Number = 0;
	else
	BMK3.Number=BMK3_ALL_HP/BMK3.HP;
	
	BMK4_ALL_HP=BMK4_ALL_HP-GERMAN_DMG;
 	if(BMK4_ALL_HP<=0)
	BMK4.Number = 0;
	else
	BMK4.Number=BMK4_ALL_HP/BMK4.HP;
	
	BMK5_ALL_HP=BMK5_ALL_HP-GERMAN_DMG;
 	if(BMK5_ALL_HP<=0)
	BMK5.Number = 0;
	else
	BMK5.Number=BMK5_ALL_HP/BMK5.HP;
	
	CMK1_ALL_HP=CMK1_ALL_HP-GERMAN_DMG;
 	if(CMK1_ALL_HP<=0)
	CMK1.Number = 0;
	else
	CMK1.Number=CMK1_ALL_HP/CMK1.HP;
	
	CMK2_ALL_HP=CMK2_ALL_HP-GERMAN_DMG;
 	if(CMK2_ALL_HP<=0)
	CMK2.Number = 0;
	else
	CMK2.Number=CMK2_ALL_HP/CMK2.HP;
	
	CMK3_ALL_HP=CMK3_ALL_HP-GERMAN_DMG;
 	if(BMK3_ALL_HP<=0)
	CMK3.Number = 0;
	else
	CMK3.Number=CMK3_ALL_HP/CMK3.HP;
	
	CMK4_ALL_HP=CMK4_ALL_HP-GERMAN_DMG;
 	if(CMK4_ALL_HP<=0)
	CMK4.Number = 0;
	else
	CMK4.Number=CMK4_ALL_HP/CMK4.HP;
	
	CMK5_ALL_HP=CMK5_ALL_HP-GERMAN_DMG;
 	if(CMK5_ALL_HP<=0)
	CMK5.Number = 0;
	else
	CMK5.Number=CMK5_ALL_HP/CMK5.HP;
	
//	printf("FRENCH_DMG: %d",FRENCH_DMG);
int BroomBar_ALL_HP=(BroomBar.HP*BroomBar.Number);
//	printf("\nBroomBar ALL HP=%d",BroomBar_ALL_HP);
//system("pause");
	BroomBar_ALL_HP=BroomBar_ALL_HP-FRENCH_DMG;
	if(BroomBar_ALL_HP<0)
	BroomBar_ALL_HP=0;
	BroomBar.Number=BroomBar_ALL_HP/BroomBar.HP;
//	printf("\nBroomBar ALL HP=%d",BroomBar_ALL_HP);
int Reward = 1250 * _5 - BroomBar_ALL_HP;
	budget += Reward;
	MKenemy+=1;
	
//	system("pause");
break;
}
default:
{
printf("ERROR: INVALID ENEMY SELECTED!");
break;
}
}
}
if(menu2==4)
{
system("cls");

if(MKlevel>=1)
{printf(" #:#o oo         #:#    ");}

if(MKlevel>=2)
{printf("#:#-------------#:# 	");}

if(MKlevel>=3)
{printf("#::::::#:|:::###::# 	");}

if(MKlevel>=4)
{printf("#::#############::# 	");}

if(MKlevel==5)
{printf("#:#:::::::::::::#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf(" #:#OO OO        #:# 	");}

if(MKlevel>=2)
{printf("#:#   #     #   #:# 	");}

if(MKlevel>=3)
{printf("#:::::#::|::#####:# 	");}

if(MKlevel>=4)
{printf("#:##           ##:# 	");}

if(MKlevel==5)
{printf("#:#::::::#::::::#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf(" #:# OO OO       #:# 	");}

if(MKlevel>=2)
{printf("#:# ##### ##### #:# 	");}

if(MKlevel>=3)
{printf("#::###:::|:::###::# 	");}

if(MKlevel>=4)
{printf("#:## ###   ### ##:# 	");}

if(MKlevel==5)
{printf("#:#:::#######:::#:# 	");}
	
printf("\n");

if(MKlevel>=1)
{printf(" #:#  || ||      #:# 	");}

if(MKlevel>=2)
{printf("#:# # #   # #   #:# 	");}

if(MKlevel>=3)
{printf("#:#####::|::#####:# 	");}

if(MKlevel>=4)
{printf("#:## #### #### ##:# 	");}

if(MKlevel==5)
{printf("#:#::::::#::::::#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf(" #:#  |# #|# #   #:# 	");}

if(MKlevel>=2)
{printf("#:# ##### ##### #:# 	");}

if(MKlevel>=3)
{printf("---------#--------- 	");}

if(MKlevel>=4)
{printf("#:## ## ### ## ##:# 	");}

if(MKlevel==5)
{printf("#:#:###########:#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf(" #:# ##########  #:# 	");}

if(MKlevel>=2)
{printf("#:#   # #   # # #:# 	");}

if(MKlevel>=3)
{printf("#::###:::|:#::::::# 	");}

if(MKlevel>=4)
{printf("#:## ##  #  ## ##:# 	");}

if(MKlevel==5)
{printf("#:#::::::#::::::#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf(" #:# ########### #:# 	");}

if(MKlevel>=2)
{printf("#:# ##### ##### #:# 	");}

if(MKlevel>=3)
{printf("#:#####::|::#:::::# 	");}

if(MKlevel>=4)
{printf("#::####     ####::# 	");}

if(MKlevel==5)
{printf("#:#::::::#::::::#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf(" #:# ########### #:# 	");}

if(MKlevel>=2)
{printf("#:#   #     #   #:# 	");}

if(MKlevel>=3)
{printf("#::###:::|:::###::# 	");}

if(MKlevel>=4)
{printf("#::::###   ###::::# 	");}

if(MKlevel==5)
{printf("#:#::::::#::::::#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf(" #:#-------------#:# 	");}

if(MKlevel>=2)
{printf("#:#-------------#:# 	");}

if(MKlevel>=3)
{printf("#:#####::|::#####:# 	");}

if(MKlevel>=4)
{printf("#:::::::###:::::::# 	");}

if(MKlevel==5)
{printf("#:#::::::#::::::#:# 	");}

printf("\n");

if(MKlevel>=1)
{printf("1:INDUSTRIAL IMPROVEMENT ");}

if(MKlevel>=2)
{printf("  2:NERF PRICES      ");}

if(MKlevel>=3)
{printf("  3:PROFESSIONAL AMRY  ");}

if(MKlevel>=4)
{printf("    4:LORRAINE WALLS    ");}

if(MKlevel==5)
{printf("      5:FRENCH FURY      ");}

printf("\n");
scanf("%d",&activetedID);
int IDbackup = activetedID;
switch(activetedID)
{
case 1:
{
activetedID=INDUSTRY_IMPROVEMENT.IDactivation;
if(IDbackup!=activetedID)
{
D1=0;
D2=0;
D3=0;
D4=0;
D5=0;
}
break;
}

case 2:
{
if(MKlevel>=NERF_PRICES.MKLEVEL)
{activetedID=NERF_PRICES.IDactivation;
if(IDbackup!=activetedID)
{
D1=0;
D2=0;
D3=0;
D4=0;
D5=0;
}}
else
{
system("cls");
printf("ERROR");
system("pause");
activetedID=0;
}
break;
}

case 3:
{
if(MKlevel>=PROFESSIONAL_ARMY.MKLEVEL)
{activetedID=PROFESSIONAL_ARMY.IDactivation;
if(IDbackup!=activetedID)
{
D1=0;
D2=0;
D3=0;
D4=0;
D5=0;
}}
else
{
system("cls");
printf("ERROR");
system("pause");
activetedID=0;
}
break;
}

case 4:
{
if(MKlevel>=LORRAINE_WALLS.MKLEVEL)
{activetedID=LORRAINE_WALLS.IDactivation;
if(IDbackup!=activetedID)
{
D1=0;
D2=0;
D3=0;
D4=0;
D5=0;
}}
else
{
system("cls");
printf("ERROR");
system("pause");
activetedID=0;
}
break;
}

case 5:
{
if(MKlevel>=FRENCH_FURY.MKLEVEL)
{activetedID=FRENCH_FURY.IDactivation;
if(IDbackup!=activetedID)
{
D1=0;
D2=0;
D3=0;
D4=0;
D5=0;
}}
else
{
system("cls");
printf("ERROR");
system("pause");
activetedID=0;
}
break;
}



}


}
if(menu2==5)
{
printf("IN DEVELOPMENT!!!");
system("pause");
}
}while(sempre2==1);
system("pause");
system("cls");
break;
}
case 2:
{
int menu2;
system("cls");
printf("1:Equipments\n");
printf("2:Interface\n");
scanf("%d",&menu2);
switch(menu2)
{
case 1:
{
system("cls");
printf("##     ##    ###     ######   #### ##    ##  #######  ########\n");
printf("###   ###   ## ##   ##    ##   ##  ###   ## ##     ##    ##   \n");
printf("#### ####  ##   ##  ##         ##  ####  ## ##     ##    ##   \n");
printf("## ### ## ##     ## ##   ####  ##  ## ## ## ##     ##    ##   \n");
printf("##     ## ######### ##    ##   ##  ##  #### ##     ##    ##   \n");
printf("##     ## ##     ## ##    ##   ##  ##   ### ##     ##    ##   \n");
printf("##     ## ##     ##  ######   #### ##    ##  #######     ##   \n");
printf("\n");
printf("Germany Equipments:\n");
printf("\n");
printf("Panzer II		Panzer III:		Panzer IV:		Panzer IV-H:		BroomBar:\n");
printf("Sprite:			Sprite:			Sprite:			Sprite:			Sprite:\n");
printf("____&&~_		___&&&-_		__0###-_		__0###-__		/####co\n");
printf("--00000-		-000000-		-000000-		-0#####0-		-000000-\n");
printf("HP=5			HP=10			HP=15			HP=15			HP=15	\n");
printf("Damage=5		Damage=15		Damage=15		Damage=20		Damage=30");
printf("\n\n");
printf("French Equipments:\n");
printf("\n");
printf("Bunker MK1:		Bunker MK2:		Bunker MK3:		Bunker MK4:		Bunker MK5:\n");
printf("Sprite:			Sprite:			Sprite:			Sprite:			Sprite:\n");
printf(":::#####:::		:::#####:::		:::#####:::		:::#####:::		:::#####:::\n");
printf("###########		###########		###########		###########		###########\n");
printf("::###1###::		::###2###::		::###3###::		::###4###::		::###5###::\n");
printf("###########		###########		###########		###########		###########\n");
printf("HP=15			HP=20			HP=25			HP=30			HP=40	\n");
printf("Demage=5		Demage=10		Demage=15		Demage=20		Demage=25\n");
printf("Price = 250$		Price = 500$		Price = 750$		Price = 1000$ 		Price = 1250$\n");
printf("\n");
printf("Cannon MK1:		Cannon MK2:		Cannon MK3:		Cannon MK4:		Cannon MK5:\n");
printf("Sprite:			Sprite:			Sprite:			Sprite:			Sprite:\n");
printf(":###:::::::		:###:::::::		:###:::::::		:###:::::::		:###:::::::\n");
printf(":::###:::::		:::###:::::		:::###:::::		:::###:::::		:::###:::::	\n");
printf(":::::#1##::		:::::#2##::		:::::#3##::		:::::#4##::		:::::#5##::	\n");
printf("###########		###########		###########		###########		###########\n");
printf("HP=5			HP=10			HP=15			HP=20			HP=25	\n");
printf("Demage=15		Demage=20		Demage=25		Demage=30		Demage=35\n");
printf("Price = 250$		Price = 500$		Price = 750$		Price = 1000$ 		Price = 1250$\n");
printf("\n");
system("pause");
system("cls");
break;
}
case 2:
{
system("cls");
printf("    #        #         1      ****::#::****  #|||##|||||##+   |1-2-3-4-5    #     #   \n");
printf(" #######    ###        1      ****#####****  #|||##|||||###+  |:::::::::  ##### ##### \n");
printf(" #  #      #####       1      ***:**#**:***  #M:A:G:I:N:O:T#  |::#####::  # #   # #   \n");
printf(" #######  #12345#      1      *###########*  ###############  |:#######:  ##### ##### \n");
printf("    #  # ### # ### ####0##### ***:::#:::***  ####Lethers####  |::#####::    # #   # # \n");
printf(" #######     #         3      ***:::#:::***  ###& Numbers###  |:#######:  ##### ##### \n");
printf("    #       ###        3      ***:::#:::***  ###############  |:MAGINOT:    #     #   \n");
printf("--------------------------------------------------------------------------------------\n");
printf("1:BUY  | 2:UPGRADE | 3:ATTACK | 4:DOCTRINES|       5:SAVE     | MK level |   Budget  |\n");
printf("--------------------------------------------------------------------------------------\n");
printf("BUY: place to buy new defenses, both cannons and bunkers\n");
printf("UPGRADE:This option is to acquire more modern weapons, as more enemies appear\n");
printf("ATTACK:Make a precise attack, whenever you target an enemy, the Germans always attack, and then they attack\n");
printf("DOCTRINE:A key piece in a battle, each one provides improvements in something like reducing prices, improving HP, improving damage, etc...\n");
printf("SAVE:Its only Just Safe\n");
printf("MK level:Its your upgrade level\n");
printf("Budget: Its your money\n");
system("pause");
system("cls");
break;
}
default:
{
system("cls");
printf("ERROR: INVALID OPTION\n");
system("pause");
system("cls");
}
}
break;
}
case 3:{
system("cls");
return 0;
break;
}
}
}while(sempre==1);
}


//OTHER IDEAS

//printf("Anti-air MK1:		Anti-air MK2:		Anti-air MK3:		Anti-air MK4:		Anti-air MK5:\n");
//printf("Sprite:			Sprite:			Sprite:			Sprite:			Sprite:		\n");
//printf(":::\\:::::::::		:::\\:::::::::		:::\\:::::::::		:::\\:::::::::		:::\\:::::::::\n");
//printf("::::\�##::::::		::::\�##::::::		::::\�##::::::		::::\�##::::::		::::\�##:::::: \n");
//printf(":::::#1#:::::		:::::#2#:::::		:::::#3#:::::		:::::#4#:::::		:::::#5#::::: \n");
//printf("#############		#############		#############		#############		############# \n");
//printf("Price = 250$		Price = 500$		Price = 750$		Price = 1000$ 		Price = 1250$\n");
//if(MKlevel>=1)
//{
// printf("                                    Upgrades\n");
// printf("                         |     #:#:::::::::::::#:#     \n"); 
// printf("                         |     #:#:::::::::::::#:#     \n"); 
// printf("                         |     #:#::_______::::#:#     \n"); 
// printf("                         |     #:#::|++*++|::::#:#     \n"); 
// printf("                         |     #:#::|++*++|::::#:#     \n"); 
// printf("                         |     #:#:___________:#:#     \n"); 
// printf("                         |     #:#:|+#** **#0#:#:#     \n"); 
// printf("                         |     #:#:|+#** **#0#:#:#     \n"); 
// printf("                         |     #:#:|+#** **#0#:#:#     \n"); 
// printf("                         |     #:#:|+#** **#0#:#:#     \n");
// printf("                         |     1) RESEARCH CENTER      \n");
// printf("                         |     REQUIRES:#              \n");
// printf("      Doctrines          |     250$     #              \n");
// printf("          ###############################                    \n");
// printf("          #              |              #                    \n");  }
// if(MKlevel>=2)
// {
// printf(" #::::::#:|:::###::#     |     #:#:::::::::::::#:#           #:#::::::#****#:#:#\n");
// printf(" #:::::#::|::#####:#     |     #:#::::#####::::#:#           #:#::::::#****#:#:#\n");
// printf(" #::###:::|:::###::#     |     #:#:::::#:#:::::#:#           #:#::#####****#:#:#\n");
// printf(" #:#####::|::#####:#     |     #:#:::::#:#:::::#:#           #:#:#*********#:#:#\n");
// printf(" ---------#---------     |     #:#::::#:::#::::#:#>--------->#:#:###########:#:#\n");
// printf(" #::###:::|:#::::::#     |     #:#:::#*****#:::#:#           #:#:::::::::::::#:#\n"); 
// printf(" #:#####::|::#:::::#     |     #:#::#***1***#::#:#           #:#::___000___::#:#\n");
// printf(" #::###:::|:::###::#     |     #:#:#*********#:#:#           #:#:|||||||||||:#:#\n");
// printf(" #:#####::|::#####:#     |     #:#::#########::#:#           #:#:###########:#:#\n");
// printf(" 2)PROFESSIONAL ARMY     |     3) RESEARCH UPGRADE              4) LAND-MINES   \n"); 
// printf("REQUIRES: #              |     REQUIRES:#                    REQUIRES:          \n");
// printf("750$      #              |     1000$    #                    750$               \n");                             
// printf("25E       #              |              #                    25E\n");}
// if(MKlevel>=3)
// {
// printf(" #:#-------------#:#     |     #:#:::::::::::::#:#           #:#::::_____::::#:#\n");
// printf(" #:#   #     #   #:#     |     #:#::::#####::::#:#           #:#:::|O|3|O|:::#:#\n");
// printf(" #:# ##### ##### #:#     |     #:#:::::#:#:::::#:#           #:#:###########:#:#\n");
// printf(" #:# # #   # #   #:#     |     #:#:::::#:#:::::#:#           #:#::::_____::::#:#\n");
// printf(" #:# ##### ##### #:#     |     #:#::::#:::#::::#:#>--------->#:#:::|O|2|O|:::#:#\n");
// printf(" #:#   # #   # # #:#     |     #:#:::#*****#:::#:#           #:#:###########:#:#\n");
// printf(" #:# ##### ##### #:#     |     #:#::#***2***#::#:#           #:#::::_____::::#:#\n");
// printf(" #:#   #     #   #:#     |     #:#:#*********#:#:#           #:#:::|O|1|O|:::#:#\n");
// printf(" #:#-------------#:#     |     #:#::#########::#:#           #:#:###########:#:#\n");
// printf(" 5) DOWN PRICES MK:1     |     6) RESEARCH UPGRADE          7)RETRACTABLE BUNKERS\n");
// printf("REQUIRES: #              |     REQUIRES:#                    REQUIRES:          \n");
// printf("1250$     #              |     2000$    #                    1500$              \n");                                                                    
// printf("100E      #              |              #                    100E\n");}
// if(MKlevel>=4)
// {
// printf(" #:#-------------#:#     |     #:#:::::::::::::#:#           #::#############::#           #:#:::::::::::::#:#\n");
// printf(" #:#   #     #   #:#     |     #:#::::#####::::#:#           #:##           ##:#           #:#:__0-_:__0-_:#:#\n");
// printf(" #:# ##### ##### #:#     |     #:#:::::#:#:::::#:#           #:## ###   ### ##:#           #:#:00000:00000:#:#\n");
// printf(" #:# # #   # #   #:#     |     #:#:::::#:#:::::#:#           #:## #### #### ##:#           #:#:__0-_:__0-_:#:#\n");
// printf(" #:# ##### ##### #:#     |     #:#::::#:::#::::#:#>--------->#:## ## ### ## ##:#>--------->#:#:00000:00000:#:#\n");
// printf(" #:#   # #   # # #:#     |     #:#:::#*****#:::#:#           #:## ##  #  ## ##:#           #:#:__0-_:__0-_:#:#\n");
// printf(" #:# ##### ##### #:#     |     #:#::#***3***#::#:#           #::####     ####::#           #:#:00000:00000:#:#\n");
// printf(" #:#   #     #   #:#     |     #:#:#*********#:#:#           #::::###   ###::::#           #:#:__0-_:__0-_:#:#\n");
// printf(" #:#-------------#:#     |     #:#::#########::#:#           #:::::::###:::::::#           #:#:00000:00000:#:# \n");
// printf(" 8) DOWN PRICES MK:2     |     9) RESEARCH UPGRADE            10) LORRAINE WALLS           11)BRITISH CRUZADERS\n");
// printf("REQUIRES: #              |     REQUIRES:#                     REQUIRES:                    REQUIRES:          \n");
// printf("2500$     #              |     4000$    #                     1750$                        1500$\n"); 
// printf("200E      #              |              #                     500E                         500E\n");} 
// if(MKlevel==5) 
// {                                                                 
// printf("----------#-----------------------------#---------------------------------------\n");
// printf("SUPER     #                             #\n");
// printf("DOCTRINES #                             #\n");
// printf(" #:#:__0-_:__0-_:#:#           #:#:::::::::::::#:#\n"); 
// printf(" #:#:00000:00000:#:#           #:#::::::#::::::#:#\n"); 
// printf(" #:#:__0-_:__0-_:#:#           #:#:::#######:::#:#\n"); 
// printf(" #:#:00000:00000:#:#           #:#::::::#::::::#:#\n"); 
// printf(" #:#:__0-_:__0-_:#:#           #:#:###########:#:#\n"); 
// printf(" #:#:00000:00000:#:#           #:#::::::#::::::#:#\n"); 
// printf(" #:#:__0-_:__0-_:#:#           #:#::::::#::::::#:#\n"); 
// printf(" #:#:00000:00000:#:#           #:#::::::#::::::#:#\n"); 
// printf(" #:#:__0-_:__0-_:#:#           #:#::::::#::::::#:#\n"); 
// printf(" #:#:00000:00000:#:#           #:#::::::#::::::#:#\n");
// printf("12)FRENCH BLITZKRIENG            13)FRENCH FURY\n");
// printf("REQUIRES:                      REQUIRES:      \n");
// printf("MK:5                           MK:5           \n");
// printf("3000$                          3000$           \n");
// printf("750E                           750E");}
